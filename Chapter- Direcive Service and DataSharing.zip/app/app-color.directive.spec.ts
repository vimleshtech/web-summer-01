import { AppColorDirective } from './app-color.directive';

describe('AppColorDirective', () => {
  it('should create an instance', () => {
    const directive = new AppColorDirective();
    expect(directive).toBeTruthy();
  });
});
