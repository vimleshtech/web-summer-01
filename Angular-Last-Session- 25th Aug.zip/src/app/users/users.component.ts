import { Component, OnInit } from '@angular/core';

import { User }    from '../user';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  //object of dropdown list
  address = ['Delhi', 'Pune','Hyd', 'Banglore'];

  //create object of model class (User.ts)
  model = new User(18, 'Nitin', 'nitin@gmail.com', this.address[0]);
  
  submitted = false;

  users=[]
  onSubmit() { 
    
    this.submitted = true;

    this.users.push(this.diagnostic);
    console.log(this.users);
    
  
  }

// TODO: Remove this when we're done
  get diagnostic() { 

    try{

        var a = 11;
        var b =0;
        var c = a/b;

        console.log('data : ',c);

    }catch{

      console.log('some error');
    }
    return JSON.stringify(this.model); 
  
  }

}
