import { Directive,ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appAppColor]'
})
export class AppColorDirective {

  constructor(private el:ElementRef ) {

      el.nativeElement.style.backgroundColor = 'green';
      el.nativeElement.style.color = 'white';
    //document.getElementById('ab').style.color="red";      

   }

   @HostListener('mouseenter') 
   onMouseEnter() {

    this.el.nativeElement.style.backgroundColor = 'black';
    this.el.nativeElement.style.color = 'white';

  }
 
  @HostListener('mouseclick') 
  onMouseClick() {

   this.el.nativeElement.style.backgroundColor = 'yellow';
   this.el.nativeElement.style.color = 'white';

 }
  @HostListener('mouseleave') onMouseLeave() 
  {
    this.el.nativeElement.style.backgroundColor = 'red';
    this.el.nativeElement.style.color = 'white';
  }
 


}
