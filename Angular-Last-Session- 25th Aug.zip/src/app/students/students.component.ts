import { Component, OnInit } from '@angular/core';

import { Student } from 'src/app/student';
import { StudentService } from 'src/app/students.service';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {

  students: Student[] = [];
  
      constructor(private studentservice: StudentService) {}
  
      ngOnInit() {

          const studentsObservable = this.studentservice.getStudents();

          studentsObservable.subscribe((studentsData: Student[]) => {

              this.students = studentsData;
              
          });
      }

}
