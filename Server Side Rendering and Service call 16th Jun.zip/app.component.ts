
import { Component } from '@angular/core';

@Component({

  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{

  
  //name='Raman Sinha';
  //name:string='Raman Sinha';
  name='Raman Sinha'
  pid:number;
  pname:string;
  pprice:number;
  pquantity:number;
  total:number;

  searchtext="" 

  itemlist=[]


  
  setsearchtext(e){

      this.searchtext  = e.target.value;
                        //document.getElementById().value;

  }
  getData(){


    console.log(this.searchtext.length);
    if(this.searchtext.length>0)
    {      

      fetch("https://jsonplaceholder.typicode.com/todos/"+this.searchtext).then(a =>a.json())
      .then(out => 
      
                this.itemlist.push(out)
              //console.log(out)

    );
      
    }
    else{

      fetch("https://jsonplaceholder.typicode.com/todos").then(a =>a.json()).then(out => 
      
      this.itemlist=out 

      //console.log(out)
    
    );

    }



    console.log(this.itemlist);

  }

  setpid(event){

    this.pid = event.target.value;
    console.log(this.pid);


  }
setpname(event){
  this.pname = event.target.value;
}
setpprice(event){
  this.pprice = event.target.value;
}

setpquantity(event){

  this.pquantity = event.target.value;
}
  
  frm_submit(){
    //alert('hi, test call ');
    //alert('hi, test call ');

    this.total = this.pquantity*this.pprice;

  }
}
