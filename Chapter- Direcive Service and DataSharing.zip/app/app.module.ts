import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

//
import { AppComponent } from './app.component';
import { AppColorDirective } from './app-color.directive';


import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    AppColorDirective,
    AppComponent,
    HeaderComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  
  bootstrap: [AppComponent]
  
})
export class AppModule { }
