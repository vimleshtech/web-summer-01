import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor() { 

  }



  incomeTax(amt:number){

    var tax =0;
    if (amt<300000){
      tax =0;
    }
    else if(amt<500000){
      tax = (amt-300000)*.05;
    }
    else if(amt <1000000){

      tax =  10000 + (amt-500000)*.20;

    }
    else{
      tax =  110000 + (amt-1000000)*.30;
    }

    return tax;
  }

  salaryCal(bsal:number){
    
    var hra = bsal*.40;
    var da = bsal*.20;
    var msal =hra+da+bsal;
    var ysal = msal*12;
    return ysal;

  }
}
