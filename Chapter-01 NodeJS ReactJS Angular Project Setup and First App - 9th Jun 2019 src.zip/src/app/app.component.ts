import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  //declare variables
  name
  desgination
  contact 
  list=[]
  delete=[]


  //functions
  setName(event){
      this.name = event.target.value; //document.getElementById().value
      console.log(this.name);

  }
  setDesig(event){
    this.desgination = event.target.value; //document.getElementById().value
    console.log(this.desgination);

  }
  setContact(event){

    this.contact = event.target.value; //document.getElementById().value
    console.log(this.contact);

  }



  frm_sub()
  {
      this.list.push({name:this.name,des:this.desgination,con:this.contact});

      console.log(this.list);

  }

  row_delete(ind){

    //this.list.pop();
    this.list.splice(ind,1); //remove index from 1 row 

    
  }
}
