
import { Component } from '@angular/core';

import { MyserviceService } from 'src/app/myservice.service';

@Component({

  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{

  
  //name='Raman Sinha';
  //name:string='Raman Sinha';
  name='Raman Sinha'
  pid:number;
  pname:string;
  pprice:number;
  pquantity:number;
  total:number;

  gender='';
  hobbies='';
  email='';
  pwd='';

  searchtext="" 

  itemlist=[]


  constructor(private obj : MyserviceService){



  }

  setMale(){
    this.gender="Male";
  }

  setFemale(){
    this.gender="Female";
  }
  
  setEmail(event){
      this.email = event.target.value;
  }
  setPwd(event){

    this.pwd = event.target.value;

  }
  register(){


    console.log(this.email);
    console.log(this.pwd);

    localStorage.setItem("user",this.email);
    localStorage.setItem("pwd",this.pwd);
    

  }
  setCricket(){
    this.hobbies ="Cricket";
  }

  setsearchtext(e){

      this.searchtext  = e.target.value;
                        //document.getElementById().value;

  }
  getData(){


    console.log(this.searchtext.length);
    if(this.searchtext.length>0)
    {      

      fetch("https://jsonplaceholder.typicode.com/todos/"+this.searchtext).then(a =>a.json())
      .then(out => 
      
                this.itemlist.push(out)
              //console.log(out)

    );
      
    }
    else{

      fetch("https://jsonplaceholder.typicode.com/todos").then(a =>a.json()).then(out => 
      
      this.itemlist=out 

      //console.log(out)
    
    );

    }



    console.log(this.itemlist);

  }

  setpid(event){

    this.pid = event.target.value;
    console.log(this.pid);


  }
setpname(event){
  this.pname = event.target.value;
}
setpprice(event){
  this.pprice = event.target.value;
}

setpquantity(event){

  this.pquantity = event.target.value;
}
  
  frm_submit(){
    //alert('hi, test call ');
    //alert('hi, test call ');


    this.total = this.pquantity*this.pprice;

    var ysal = this.obj.salaryCal(this.total);
    console.log(ysal);

    var tax = this.obj.incomeTax(ysal);
    console.log(tax);
    

  }
}
