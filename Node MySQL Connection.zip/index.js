var express = require('express');  //load/import the library 
var mysql = require('mysql');

//local mysql db connection
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'sales'
});

connection.connect(function(err) {
    if (err) throw err;
});


var app = express();	//create object of express class

app.get('/',function(req,res){
		res.send('hi');
});

app.get('/todos',function(req,re){

    connection.query("select * from product", function(err,res){

            if(err){
                    console.log(err);
            }
            else{
                    console.log(res);
                    
            re.send(res);

            }
    });

    
})


app.get('/products',function(req,res){

    res.json([{pid:1,pname:'dove'},{pid:2,pname:'iphone'}]);

})


app.listen(3011,function(){
			console.log('you can access service at 3011 port ');	
})	
