
export class Student {
    id: number;
    name: string;
    enrollmentNumber: number;
    college: string;
    university: string;
}