
var express = require('express');

var app = express();

app.get('/',function(req,res){


    res.send("hi, from server ");

})

app.post('/save',function(req,res){


    var data = req.body;
    
})


app.get('/home',function(req,res){

    res.send("hi, from home function  ");
})



app.get('/list',function(req,res){
    
    res.send("hi, from list function  ");
    })

    
    
app.get('/todos',function(req,res){
    
    //res.send("hi, from todo ");
    res.json({id:111,name:'nitin'});


    })
    

var listten = app.listen(3010);


